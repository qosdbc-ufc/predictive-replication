/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package qosdbc.provider.api;

/**
 *
 * @author Leonardo Oliveira Moreira
 */
public final class VirtualMachineState {

    public static final int RUNNING = 1;
    public static final int STOPPED = 0;

    private VirtualMachineState() {
    }
}