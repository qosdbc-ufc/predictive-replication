#    Importe a chave pública do CRAN server do R.
#        Siga as instruções presentes no link http://cran-r.c3sl.ufpr.br/bin/linux/ubuntu/
#        Procure pela seção "SECURE APT", onde deve ter um comando semelhante ao abaixo
#
#        sudo apt-key adv --keyserver keyserver.ubuntu.com --recv-keys E084DAB9

#    Edite seu arquivo /etc/apt/sources.list, adicionando a seguinte linha
#        deb http://cran-r.c3sl.ufpr.br/bin/linux/ubuntu raring/
#    Execute o comando sudo apt-get update
#    Execute o comando abaixo

#        sudo apt-get install r-base

#    Finalmente o R mais novo deve estar instalado
#    Execute o R pelo menu ou pelo terminal usando o comando R
#    Instale o pacote forecast, usando os seguintes comandos do R
#        update.packages()
#        install.packages('codetools')
#        install.packages('forecast')
#    Verifique a instalação usando os seguintes comandos
#        library('forecast')
#        auto.arima, que vai imprimir o código da função