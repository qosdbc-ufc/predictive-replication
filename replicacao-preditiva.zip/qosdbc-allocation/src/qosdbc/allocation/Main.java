package qosdbc.allocation;



import java.util.ArrayList;


public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		VM vm1 = new VM("vm1");
//		
//		Tenant t1 = new Tenant("t1");
//		t1.addResponseTime(50L);
//		t1.addResponseTime(100L);
//		
//		Tenant t2 = new Tenant("t2");
//		t2.addResponseTime(100L);
//		t2.addResponseTime(190L);
//		
//		vm1.addTenant(t1);
//		vm1.addTenant(t2);
//		
//		VM vm2 = new VM("vm2");
//		
//		Tenant t3 = new Tenant("t2");
//		t3.addResponseTime(30L);
//		t3.addResponseTime(20L);
//		
//		Tenant t4 = new Tenant("t2");
//		t4.addResponseTime(80L);
//		t4.addResponseTime(30L);
//		
//		vm2.addTenant(t3);
//		vm2.addTenant(t4);
//		
//		
//		ArrayList<VM> vms = new ArrayList<VM>();
//		vms.add(vm1);
//		vms.add(vm2);
//		
//		VM v = Alocate.alocate(vms, t2);
//		System.out.println(v.getName());
		
		VM vm =new Allocate("10.159.62.151", "tpcc").alocate();
		System.out.println(vm.getName());
//		for(Tenant t : vm.getTenants()){
//			System.out.println("Tenant");
//			System.out.println(t.computeMean());
//			for (long l :  t.getResponseTimes()){
//				System.out.println(l);
//			}
//		}

	}

}
